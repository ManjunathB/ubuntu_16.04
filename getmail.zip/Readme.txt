INDEX

 - description
 - installation
 - what's new in this version
 - usage
 - examples
 - copyright
 - author and availablity


DESCRIPTION:

Getmail is a Windows 95/NT console utility to download the contents of a pop3
mailbox.  It's ideal for scripts which need to get input from a mail message.
Using your language of choice, it allows you to add email capability to any
process (mail responders, or even lists).  Configuration information can be
saved in the registry.

INSTALLATION:

1) Copy the file "gwinsock.dll" to your "\WINNT\SYSTEM32" directory, or to any
   other directory in your path. (Check if you already have it and only copy
   the DLL if the date is more recent than the existing one)

2) Copy the file "Getmail.exe" to your "\WINNT\SYSTEM32" directory, or to any
   other directory in your path.

3) Run "Getmail -install yourhost.site.blah.blah youremail@site.blah.blah yourpassword"
   It's recommended to put a fake password in here, and then provide the password each
   time you run Getmail, for obvious security reasons.

   You can optionally specify some other parameters.  In order, then are "delete",
   "Xtract", "Tries", "Port", and "Profile".  delete/xtract are either "-","Yes",
   or "No".  Tries is a number, or "-" for the default of 1.  Specifying a "Profile"
   will allow the settings to be saved with a different profile name.

WHAT'S NEW IN THIS VERSION

version 1.33
    - Fixed inability to parse some mail messages properly

version 1.32
    - Added "-headersonly" option to download only headers

version 1.31
    - Added "-domainstamp" option to attach sender's domain to each extracted file

version 1.30
    - Fixed extraction bug when an extraneous "Status" header appeared after Content- lines, but before message body

version 1.29
   - Fixed minor bug with "-plain" extraction (occassional extra characters added to output)

version 1.28
   - Return code is now zero on successs, non-zero on error (used to be the number of
     messages retrieved).

version 1.27
   - Unique filename generation changed to ensure that file extension does change

version 1.26
   - Added "-ti" timeout option

version 1.25
   - Getmail now generates non-conflicting attachment names for all extracted attachments

version 1.24
   - Some attachments (from bulk mailers) were previously ignored.  Fixed

version 1.23
   - Added character filter to filename creation routine.  Disallowed characters
     are now converted to an underscore ("_")
   - Addded "-nomsg" command line option, which deletes MSG*.TXT files after download

version 1.22
   - Getmail now converts quoted-printable text to un-mangled text
   - Fixed bug in unique filename generation that affected quoted-printable attachments

version 1.21
   - Enhanced how getmail deals with messages that have embedded multipart messages

version 1.20
   - Added "-dir" command to direct file output to an alternate directory

version 1.19
   - When "-plain" is specified, quoted-printable are also extracted
     (Note: any QP encoding is actually left intact! -- NEED TO FIX)

version 1.18
   - "-b" and "-m" were broken
   - added "-plain" to allow extraction of text/plain unencoded attachments

version 1.17
   - GWINSOCK.DLL is no longer required.
   - When download a mailbox that has multiple files with unnamed attachements,
     the generated filenames are generated as unique filenames.
   - Added "-b <n>" option to allow retrieving messages starting with # n.

version 1.16
   - Added "-forceextract" option to attempt binary file extract from a
     previously downloaded message

version 1.15a
   - Binary file attachment names can no longer include "," character

version 1.15
   - Boundary detection was broken if mailer didn't double quote the boundary

version 1.14
   - Fixed extraction of UU files where a filename isn't specified.

version 1.13
   - multi-line Content- header problem fixed

version 1.12
   - Major speed improvement for extraction of large files

version 1.11
   - Return codes fixed
   - Tightened up parsing of raw UU files

version 1.10
   - Added scanning for multi-line "Content-" headers which use tabs
   - Added ability to deal with files which don't give themselves a filename

version 1.09
   - Added scanning for multi-line "Content-" headers

version 1.08
   - Minor change to parsing of MIME headers

version 1.07
   - Extraction flag was being read as "No" from registry regardless
     of the actual setting.  Command line was unaffected.
   - Return code is # of messages downloaded.
   - The message boundary was being mis-read with some mailers.

version 1.06
   - Added support for extraction of attached 7BIT encoded ascii files

version 1.05
   - Fixed "getmail -profile" which was setting the "quiet" flag, causing no
     output to be displayed.

version 1.04
   - Added "-n" and "-m" options to extract either first "n" messages,
     or message #n

version 1.03
   - Fixed UUencoded file downloading.  It was only extracting
     MIME UUencoded files before -- now handles raw begin/end
     UUencoded files.

version 1.02
   - Can now identify and extract UUencoded files.

version 1.01
   - Added extraction of base64 encoded binary attachments (like those
     created with blat -- http://www.interlog.com/~tcharron/blat.html)

USAGE:

syntax:
  Getmail -u <user> -p <password> -s <server> [optional switches (see below)]
  Getmail -install [ see install details below ]
  Getmail -profile [-delete | "<default>"] [profile1] [profileN] [-q]
  Getmail -h [-q]

-install <server> <userid> <password> [<delete> [<xtract> [<try> [<port> [<profile>]]]]]
     : set's POP3 server, login, password, whether to delete or not (Yes/No),
       whether to automatically extract base64/7bit/UU encoded files or not (Yes/No),
       number of tries and port for profile
       (<delete> <xtract> <try> and <port> may be replaced by '-').

-u <userid>   : Specify userid on remote pop3 host
-pw <password>: Specify password for userid on remote mail host
-s <server>   : Specify mail server (pop3) to contact
-nodelete     : Do not delete messages after downloading (default)
-delete       : Delete messages after downloading
-noxtract     : Do not extract base64//7bitUU files after downloading (default)
-xtract       : Extract base64//7bitUU encoded files after downloading messages
-h            : displays this help.
-q            : supresses *all* output.
-p <profile>  : send with SMTP server, user and port defined in <profile>.
-port <port>  : port to be used on the server, defaults to POP3 (110)
-try <n times>: how many attempts to access mail.  from '1' to 'INFINITE'

EXAMPLES:

Getmail -install smtphost.bar.com foo@bar.com password   // Sets host, userid, and password
Getmail -install smtphost.bar.com foo@bar.com password Yes Yes 3 110
 // Sets host, userid, and password.  Automatic deletion after download, and extraction of files
 // 3 attempts will be made before giving up, using port 110 work
Getmail -install smtphost.bar.com foo@bar.com password Yes Yes 3 110
 // As prior, but saving profile with name "work"

Getmail -pw realpassword
// Get the mail, using configured host/userid, etc, but using the password specified.

Getmail -pw realpassword -xtract
// Get the mail, using configured host/userid, etc, but using the password specified.
// Automatically extract binary attachments

COPYRIGHT

Getmail is free for non-commercial use.  If you use it in a business environment, then
a fee of $50 USD is payable to Tim Charron.

        Tim Charron
        1911 Bough Beeches Blvd
        Mississauga, Ontario
        L4W 2J8

The author of the package is not responsible for any damage or losses that
the usage of Getmail may cause.

AUTHOR & AVAILABILITY

GetMail is written by Tim Charron (tcharron@interlog.com)
It is available from http://www.interlog.com/~tcharron/getmail.html

