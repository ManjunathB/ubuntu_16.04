/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jaxbapp;

import java.io.File;
import java.util.List;
import javax.xml.bind.JAXB;
import javax.xml.bind.JAXBElement;
import org.tml.jaxbApp.DTCData;
import org.tml.jaxbApp.DTCInfo;

/**
 *
 * @author amr06831
 */
public class JAXBApp {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        DTCInfo info=new DTCInfo();
        info.setDTCCode("P0117");
        info.setDTCDesc("Coolant temp circuit short to ground");
        DTCData data=new DTCData();
        DTCData.DTC dtc=new DTCData.DTC();
        dtc.setShortName("P0117");
        data.getDTC().add(dtc);
        JAXBElement<DTCData> elem=(new org.tml.jaxbApp.ObjectFactory()).createDTCInfo(data);
        JAXB.marshal(elem,new File("D:\\Abhijit_Work\\sample.xml"));
        
    }
}
